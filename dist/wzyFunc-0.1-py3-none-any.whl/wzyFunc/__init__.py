'''
Descripttion: Say something
version: 0.1
Author: ziyang-W, ziyangw@yeah.net
Co.: IMICAMS
Date: 2022-06-16 14:53:17
LastEditTime: 2023-08-08 17:03:59
Copyright (c) 2023 by ziyang-W (ziyangw@yeah.net), All Rights Reserved. 
'''
# 用于创建包必须的代码
import batchPlot
import calPlot
import machineLearning
import dataPrep
import statistics
if __name__ == "__main__":
    print("Running as main programme")
else:
    print("import wzyFunc package Successful")
